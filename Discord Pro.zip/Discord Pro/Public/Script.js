}
// --- VERİTABANI & AYARLAR ---
let db = {
    users: JSON.parse(localStorage.getItem('users')) || [],
    servers: JSON.parse(localStorage.getItem('servers')) || [],
    msgs: JSON.parse(localStorage.getItem('msgs')) || {}
};
let currentUser = null;
let activeContext = { type: 'dm', id: 'home', srvId: null };
let peer = null;

// --- DOSYA OKUMA YARDIMCISI ---
// Dosyaları metne çevirir (Base64)
const readFile = (file) => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
};

// --- AUTH ---
let isReg = false;
function toggleRegister() {
    isReg = !isReg;
    document.getElementById('auth-header').innerText = isReg ? "Kayıt Ol" : "Giriş Yap";
}
function login() {
    const u = document.getElementById('auth-user').value;
    const p = document.getElementById('auth-pass').value;
    if(!u || !p) return alert("Bilgileri girin!");

    if(isReg) {
        if(db.users.find(x => x.u === u)) return alert("Bu isim dolu!");
        db.users.push({ u, p, avatar: 'https://cdn.discordapp.com/embed/avatars/0.png', friends: [] });
        saveDB();
        alert("Kayıt başarılı!");
        toggleRegister();
    } else {
        const user = db.users.find(x => x.u === u && x.p === p);
        if(!user) return alert("Hatalı!");
        currentUser = user;
        initApp();
    }
}

function initApp() {
    document.getElementById('auth-screen').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
    updateProfileUI();
    renderServers();
    goHome();
}

// --- PROFİL DÜZENLEME (DOSYA DESTEKLİ) ---
function updateProfileUI() {
    document.getElementById('u-name').innerText = currentUser.u;
    document.getElementById('u-avatar').src = currentUser.avatar;
    
    // Modal içini doldur
    document.getElementById('prof-name').value = currentUser.u;
    document.getElementById('prof-preview').src = currentUser.avatar;
}

async function saveProfile() {
    const newName = document.getElementById('prof-name').value;
    const fileInput = document.getElementById('prof-file');
    
    if(fileInput.files && fileInput.files[0]) {
        // Dosya seçildiyse Base64'e çevir
        try {
            currentUser.avatar = await readFile(fileInput.files[0]);
        } catch(e) { alert("Resim yüklenemedi!"); return; }
    }
    
    currentUser.u = newName;
    
    // DB Güncelle
    const idx = db.users.findIndex(u => u.u === currentUser.u); // Buradaki mantık biraz hatalı olabilir, ID olsa daha iyi ama şimdilik isimden gidelim
    // Not: Gerçek projede ID kullanmalısın. Şimdilik referans üzerinden gidiyoruz.
    saveDB();
    updateProfileUI();
    closeModals();
}

// --- SUNUCU YÖNETİMİ ---
function renderServers() {
    const list = document.getElementById('server-list');
    list.innerHTML = "";
    db.servers.forEach(s => {
        const div = document.createElement('div');
        div.className = "server-icon";
        
        // Eğer sunucu resmi varsa onu koy, yoksa harf koy
        if(s.icon) {
            div.style.backgroundImage = `url(${s.icon})`;
            div.innerText = "";
        } else {
            div.innerText = s.name[0].toUpperCase();
            div.style.backgroundImage = "none";
        }
        
        div.onclick = () => openServer(s);
        list.appendChild(div);
    });
}

function createServer() {
    const name = document.getElementById('new-srv-name').value;
    if(!name) return;
    const newSrv = { 
        id: Date.now(), 
        name, 
        icon: null, // Başlangıçta ikon yok
        channels: [{id: 'g'+Date.now(), name: 'genel', type: 'text'}] 
    };
    db.servers.push(newSrv);
    saveDB();
    renderServers();
    closeModals();
}

function openServer(srv) {
    activeContext = { type: 'server', srvId: srv.id, srv: srv };
    document.getElementById('sidebar-title').innerText = srv.name;
    document.getElementById('srv-settings-btn').style.display = 'block'; // Ayarlar ikonunu göster
    
    const content = document.getElementById('channel-content');
    content.innerHTML = `<div onclick="openModal('modal-channel')" style="color:#5865f2; padding:10px; font-weight:bold; cursor:pointer;">+ Kanal Ekle</div>`;
    
    // Kanalları Listele
    srv.channels.forEach(ch => {
        const icon = ch.type === 'voice' ? '🔊' : '#';
        const func = ch.type === 'voice' ? `joinVoice('${ch.name}')` : `loadChat('${ch.id}', '${ch.name}')`;
        content.innerHTML += `<div class="channel-item" onclick="${func}">${icon} ${ch.name}</div>`;
    });

    // İlk text kanalını aç
    const firstTxt = srv.channels.find(c => c.type === 'text');
    if(firstTxt) loadChat(firstTxt.id, firstTxt.name);
}

// --- SUNUCU ÖZELLEŞTİRME & SİLME ---
function openServerSettings() {
    if(!activeContext.srv) return;
    document.getElementById('edit-srv-name').value = activeContext.srv.name;
    openModal('modal-server-settings');
}

async function saveServerSettings() {
    if(!activeContext.srvId) return;
    const newName = document.getElementById('edit-srv-name').value;
    const fileInput = document.getElementById('edit-srv-file');
    
    const srv = db.servers.find(s => s.id === activeContext.srvId);
    if(srv) {
        srv.name = newName;
        if(fileInput.files && fileInput.files[0]) {
            try {
                srv.icon = await readFile(fileInput.files[0]);
            } catch(e) { alert("Resim hatası"); }
        }
        saveDB();
        renderServers();
        openServer(srv); // Sidebar başlığını güncelle
        closeModals();
    }
}

function deleteServer() {
    if(confirm("Sunucuyu kalıcı olarak silmek istiyor musun?")) {
        db.servers = db.servers.filter(s => s.id !== activeContext.srvId);
        saveDB();
        renderServers();
        goHome();
        closeModals();
    }
}

// --- CHAT & DOSYA GÖNDERME ---
function loadChat(id, name) {
    activeContext.chatId = id;
    document.getElementById('chat-title').innerText = "# " + name;
    renderMsgs();
    if(window.innerWidth < 768) toggleDrawer();
}

async function handleChatFile() {
    const fileInput = document.getElementById('chat-file-input');
    const file = fileInput.files[0];
    if(!file) return;

    // Dosya boyutu kontrolü (Örn: 2MB limit)
    if(file.size > 2 * 1024 * 1024) {
        alert("Dosya çok büyük! (Max 2MB)");
        fileInput.value = ""; // Reset
        return;
    }

    const base64 = await readFile(file);
    const isImage = file.type.startsWith('image/');
    
    const msg = {
        u: currentUser.u,
        a: currentUser.avatar,
        type: isImage ? 'img' : 'file',
        content: base64, // Resim verisi veya dosya verisi
        fileName: file.name,
        time: new Date().toLocaleTimeString().slice(0,5)
    };

    saveMsg(msg);
    fileInput.value = ""; // Inputu temizle ki aynı dosyayı tekrar seçebil
}

function sendMsg() {
    const inp = document.getElementById('msg-in');
    const txt = inp.value.trim();
    if(!txt) return;

    const msg = {
        u: currentUser.u,
        a: currentUser.avatar,
        type: 'text',
        content: txt,
        time: new Date().toLocaleTimeString().slice(0,5)
    };
    saveMsg(msg);
    inp.value = "";
}

function saveMsg(msg) {
    if(!db.msgs[activeContext.chatId]) db.msgs[activeContext.chatId] = [];
    db.msgs[activeContext.chatId].push(msg);
    localStorage.setItem('msgs', JSON.stringify(db.msgs));
    renderMsgs();
}

function renderMsgs() {
    const area = document.getElementById('messages');
    area.innerHTML = "";
    const list = db.msgs[activeContext.chatId] || [];
    
    list.forEach(m => {
        let contentHtml = "";
        
        if(m.type === 'text') {
            contentHtml = `<div class="msg-text">${m.content}</div>`;
        } else if (m.type === 'img') {
            contentHtml = `<img src="${m.content}" class="msg-img" onclick="window.open(this.src)">`;
        } else if (m.type === 'file') {
            contentHtml = `
                <div class="msg-file-box">
                    <span class="msg-file-icon">📄</span>
                    <div>
                        <a href="${m.content}" download="${m.fileName}" class="msg-file-link">${m.fileName}</a>
                        <div style="font-size:10px; color:gray">İndirmek için tıkla</div>
                    </div>
                </div>`;
        }

        area.innerHTML += `
            <div class="msg-row">
                <img src="${m.a}" class="msg-avatar">
                <div class="msg-content">
                    <h4>${m.u} <span>${m.time}</span></h4>
                    ${contentHtml}
                </div>
            </div>`;
    });
    area.scrollTop = area.scrollHeight;
}

// --- DİĞER FONKSİYONLAR ---
function createChannel() {
    if(activeContext.type !== 'server') return;
    const name = document.getElementById('ch-name').value;
    const type = document.querySelector('input[name="ch-type"]:checked').value;
    
    const srv = db.servers.find(s => s.id === activeContext.srvId);
    srv.channels.push({ id: Date.now(), name, type });
    saveDB();
    openServer(srv);
    closeModals();
}

function goHome() {
    activeContext = { type: 'dm', id: 'home' };
    document.getElementById('sidebar-title').innerText = "Mesajlar";
    document.getElementById('srv-settings-btn').style.display = 'none';
    document.getElementById('channel-content').innerHTML = `<div onclick="openModal('modal-friend')" style="color:#23a559; padding:10px; font-weight:bold; cursor:pointer;">+ Arkadaş Ekle</div>`;
    currentUser.friends.forEach(f => {
        document.getElementById('channel-content').innerHTML += `<div class="channel-item" onclick="loadChat('${f}', '${f}')">👤 ${f}</div>`;
    });
}

function addFriend() {
    const name = document.getElementById('fr-name').value;
    currentUser.friends.push(name);
    saveDB();
    goHome();
    closeModals();
}

function saveDB() {
    localStorage.setItem('users', JSON.stringify(db.users));
    localStorage.setItem('servers', JSON.stringify(db.servers));
}

function joinVoice(name) {
    document.getElementById('voice-panel').style.display = 'flex';
    alert("Ses kanalına bağlanıldı: " + name);
}
function leaveVoice() { document.getElementById('voice-panel').style.display = 'none'; }
function toggleDrawer() { document.getElementById('drawer').classList.toggle('open'); }
function openModal(id) { document.getElementById(id).style.display = 'flex'; }
function closeModals() { document.querySelectorAll('.modal').forEach(m => m.style.display = 'none'); }
function toggleMic() { alert("Mikrofon Ayarı Değiştirildi"); }
