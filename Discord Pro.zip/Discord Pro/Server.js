const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer'); // Dosya yükleme kütüphanesi
const app = express();

app.use(express.json());
app.use(express.static('public'));
app.use('/uploads', express.static('uploads')); // Dosyaları dışarı açar

// ZIP dosyalarının yükleneceği yeri ayarla
const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage: storage });

const USERS_FILE = './users.json';

// Kayıt Olma
app.post('/register', (req, res) => {
    const { username, password } = req.body;
    let users = JSON.parse(fs.readFileSync(USERS_FILE));
    if (users.find(u => u.username === username)) return res.status(400).json({ msg: "Bu isim zaten var!" });
    
    users.push({ username, password });
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    res.json({ msg: "Başarıyla kayıt oldun!" });
});

// Giriş Yapma
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    let users = JSON.parse(fs.readFileSync(USERS_FILE));
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) return res.status(401).json({ msg: "Hatalı giriş!" });
    res.json({ msg: "Giriş yapıldı", user });
});

// ZIP Dosyası Yükleme
app.post('/upload', upload.single('zipFile'), (req, res) => {
    if (!req.file) return res.status(400).send('Dosya yüklenemedi.');
    res.json({ filePath: `/uploads/${req.file.filename}`, fileName: req.file.originalname });
});

app.listen(3000, () => console.log("Sunucu http://localhost:3000 adresinde hazır!"));
